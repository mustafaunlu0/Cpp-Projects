/****************************************************************************
**					SAKARYA �N�VERS�TES�
**			         B�LG�SAYAR VE B�L���M B�L�MLER� FAK�LTES�
**				    B�LG�SAYAR M�HEND�SL��� B�L�M�
**				          PROGRAMLAMAYA G�R��� DERS�
**
**				PROJE NUMARASI: 1
**				��RENC� ADI: MUSTAFA �NL�
**				��RENC� NUMARASI: b201210392
**				DERS GRUBU: A
****************************************************************************/
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <string>
#include <stdio.h>
#include <ctime>
#include <fstream>
#include <ctime>
#include<locale.h>
using namespace std;
string kullaniciAdi;
int sifre;
int secim;
char cevap = 'e';
long long tcNo = 0, uyeNo = 0, telefon = 0;
int alinacakKitapSayisi = 0;
string dogumTarihi;
string ad, soyad, gorev;
char kay�tDevam;
string kullanici_adi = "deneme";//1. Kullan�c�
int kullanici_sifre = 1234;
string kullanici_adi1 = "deneme2";//2. kKllan�c�
int kullanici_sifre1 = 4321;
long long ISBN;
string yazarAdi;
string yazarSoyadi;
string kitapIsmi;
string konu;
string tur;
int sayfaSayisi;
string oduncTarih, donusTarih;
void belirliKullanici() {
	//yukar�da belirlenen iki kullan�c� kullanicilar.txt dosyas�na yazd�r�l�r.
	ofstream dosyaYazz("kullanicilar.txt");
	dosyaYazz << kullanici_adi << " " << kullanici_sifre << endl;
	dosyaYazz << kullanici_adi1 << " " << kullanici_sifre1 << endl;
	dosyaYazz.close();
}
void kullaniciGirisi() {

	cout << "kullan�c� ad�:";
	cin >> kullaniciAdi;
	cout << "kullan�c� �ifre:";
	cin >> sifre;
}
void girisSaat() {
	//giris saati belirlenir ve ekrana yazd�r�l�r.
	time_t now = time(0);
	char* giris = ctime(&now);
	cout << "Kullan�c� Giri� Saati:" << giris;
}
void cikisSaat() {
	//c�k�� saati belirlenir ve ekrana yazd�r�l�r
	time_t now = time(0);
	char* cikis = ctime(&now);
	cout << "��k�� Saati:" << cikis << endl;
}
void anaMenu(){
	//giri� yap�ld�ktan sonra kullan�c�ya i�lem sorulur ve se�ilen i�lem yerine getirilir.
	do {
		cout << "\n1-Okuyucu Kayd�" << endl;
		cout << "2-Okuyucu Kayd� G�ncelleme" << endl;
		cout << "3-Okuyucu Silme" << endl;
		cout << "4-Okuyucu �zerindeki Kitaplar�n Listesi" << endl;
		cout << "5-Okuyucu Kitap �d�n� Alma" << endl;
		cout << "6-Okuyucu Kitap Geri D�nd�rme" << endl;
		cout << "7-Kitap Ekleme" << endl;
		cout << "8-Kitap Silme" << endl;
		cout << "9-Kitap D�zeltme" << endl;
		cout << "\n--L�tfen 1-9 Aras�nda Bir Say� Girin--" << endl;
		cin >> secim;
		cout << endl;
	} while (!(secim >= 1 && secim <= 9));
}
void okuyucuKaydi() {
	//okuyucu kayd� yap�l�r.
	ofstream dosyaYaz("okuyucular.txt", ios::app);
	cout << "***l�tfen birden fazla kelime girmeniz halinde araya '_' i�aretini koyunuz.***\n";
	//kullan�c�dan bilgileri girmesi istenir ve dosyaya yazd�r�l�r.
	do {
		cout << "okuyucunun tc kimlik numaras�n� girin:\n";
		cin >> tcNo;
		cout << "okuyucunun ad�n� girin:\n";
		cin >> ad;
		cout << "okuyucunun soyad�n� girin:\n";
		cin >> soyad;
		cout << "okuyucunun �ye numaras�n� girin:\n";
		cin >> uyeNo;
		cout << "okuyucunun telefonunu girin:\n";
		cin >> telefon;
		cout << "okuyucunun do�um tarihini g�n.ay.y�l olacak �ekilde girin:\n";
		cin >> dogumTarihi;
		cout << "okuyucunun g�revi girin:\n";
		cin >> gorev;
		cout << "okuyucunun alabilece�i kitap say�s�n� girin:\n";
		cin >> alinacakKitapSayisi;
		dosyaYaz << tcNo << " " << ad << " " << soyad << " " << uyeNo << " " << telefon << " " << dogumTarihi << " " << gorev << " " << alinacakKitapSayisi << endl;
		cout << "**okuyucu kayd� yap�lm��t�r.**\n";
		cout << "yeni bir okuyucu kayd� yapmak istiyor musunuz(e/h)" << endl;
		cin >> kay�tDevam;

	} while (!(kay�tDevam == 'h'));
}
int okuyucuKaydiGuncelleme() {
	long long arananTc;
	long long degerTutucu=0;
	cout << "g�ncelleme yap�lacak ki�inin TC numaras�:";
	cin >> arananTc;
	ifstream dosyaOku("okuyucular.txt");
	ofstream dosyaYaz("okuyucular.tmp",ios::app);
	cout << "***l�tfen birden fazla kelime girmeniz halinde araya '_' i�aretini koyunuz.***\n";
	//okuyucular.txt'teki b�t�n veriler okunur ve aranan veri yazd�l�r. Kullan�c� yeni verileri girerek de�i�im sa�lan�r.
	while (true)
	{
		dosyaOku >> tcNo >> ad >> soyad >> uyeNo >> telefon >>
			dogumTarihi >> gorev >> alinacakKitapSayisi;
		if (dosyaOku.eof()) {
			break;
		}
		if (arananTc == tcNo)
			{
				cout << "\n--Dosyadaki Mevcut Kay�t--\n";
				cout << "TC:" << tcNo << endl;
				cout << "Ad:" << ad << endl;
				cout << "Soyad:" << soyad << endl;
				cout << "�ye no:" << uyeNo << endl;
				cout << "Telefon:" << telefon << endl;
				cout << "Do�um Tarihi:" << dogumTarihi << endl;
				cout << "G�rev:" << gorev << endl;
				cout << "Al�nacak Kitap Say�s�:" << alinacakKitapSayisi << endl;
				cout << "\n--Yeni De�erler Giri�i--\n";
				cout << "TC:"; cin >> tcNo;
				degerTutucu = tcNo;
				cout << "Ad:"; cin >> ad;
				cout << "Soyad:"; cin >> soyad;
				cout << "�ye no:"; cin >> uyeNo;
				cout << "Telefon:"; cin >> telefon;
				cout << "Do�um Tarihi:"; cin >> dogumTarihi;
				cout << "G�rev:"; cin >> gorev;
				cout << "Al�nacak Kitap Say�s�:"; cin >> alinacakKitapSayisi;
				dosyaYaz << tcNo << " " << ad << " " << soyad << " " << uyeNo << " " <<
					telefon << " " << dogumTarihi << " " << gorev << " " << alinacakKitapSayisi << endl;
				tcNo = arananTc;
			}
			if(arananTc!=tcNo) 
			{
				dosyaYaz << tcNo << " " << ad << " " << soyad << " " << uyeNo << " " << telefon << " " << dogumTarihi << " " << gorev << " " << alinacakKitapSayisi << endl;
			}
			
			
	}
	tcNo = degerTutucu;
	dosyaYaz.close();
	dosyaOku.close();
	int result;
	const char old[] = "okuyucular.tmp";
	const char neww[] = "okuyucular.txt";
	remove("okuyucular.txt");
	result=rename(old, neww);
	return result;
}
int okuyucuSilme() {
	long long arananTc;
	cout << "silme i�lemi yap�lacak okuyucunun TC numaras�:";
	cin >> arananTc;

	ifstream dosyaOku("okuyucular.txt");
	ofstream dosyaYaz("okuyucular.tmp", ios::app);
	//okuyucular.txt'teki veriler okunur ve aranan veri sildirilir.
	while (true)
	{
		dosyaOku >> tcNo >> ad >> soyad >> uyeNo >> telefon >>
			dogumTarihi >> gorev >> alinacakKitapSayisi;
		if (dosyaOku.eof()) {
			break;
		}
		if (arananTc == tcNo)
		{
			cout << "\n--Silinecek Okuyucunun Mevcut Bilgileri--\n";
			cout << "TC:" << tcNo << endl;
			cout << "Ad:" << ad << endl;
			cout << "Soyad:" << soyad << endl;
			cout << "�ye no:" << uyeNo << endl;
			cout << "Telefon:" << telefon << endl;
			cout << "Do�um Tarihi:" << dogumTarihi << endl;
			cout << "G�rev:" << gorev << endl;
			cout << "Al�nacak Kitap Say�s�:" << alinacakKitapSayisi << endl;
			cout << "**silme islemi tamamland�**" << endl;
			
		}
		if (arananTc != tcNo) {
			dosyaYaz << tcNo << " " << ad << " " << soyad << " " << uyeNo << " " << telefon << " " << dogumTarihi << " " << gorev << " " << alinacakKitapSayisi << endl;
		}


	}

	dosyaYaz.close();
	dosyaOku.close();
	int result;
	const char old[] = "okuyucular.tmp";
	const char neww[] = "okuyucular.txt";
	remove("okuyucular.txt");
	result = rename(old, neww);
	return result;

}
void okuyucuUzerindekiKitap() {
	long long arananISBN;
	long long arananTC;
	cout << "okuyucunun tc girin:";
	cin >> arananTC;
	ifstream dosyaOkuma("odunc.txt");
	//odunc.txt'taki veriler okunur ve aranan veri ile o verinin bulundu�u sat�ra ula�arak �sbn kaydedilir.
	//Sonras�nda da kitaplar.txt'ye giderek sahip oldu�umuz �sbn ile kitap yazd�r�l�r.
	while (true) {
		dosyaOkuma >> ISBN >> tcNo >> oduncTarih >> donusTarih;
		if (dosyaOkuma.eof()) {
			break;
		}
		if (arananTC == tcNo) {
			arananISBN = ISBN;
			dosyaOkuma.close();
			ofstream DosyaYaz;
			dosyaOkuma.open("kitaplar.txt",ios::in);
			while (true) 
			{
				dosyaOkuma >> ISBN >> kitapIsmi >> yazarAdi >> yazarSoyadi >> konu >>
					tur >> sayfaSayisi;
				if (dosyaOkuma.eof()) {
					break;
				}
				if (arananISBN == ISBN) {
					cout << "\n--Okuyucu �zerindeki Kitap Bilgileri--\n";
					cout << "ISBN:" << ISBN << endl;
					cout << "Kitab�n �smi:" << kitapIsmi << endl;
					cout << "Yazar Ad�:" << yazarAdi << endl;
					cout << "Yazar Soyad�:" << yazarSoyadi << endl;
					cout << "Konu:" << konu << endl;
					cout << "T�r:" << tur << endl;
					cout << "Sayfa Say�s�:" << sayfaSayisi << endl;
				}
			}
			DosyaYaz.close();
		}
	}
}
void oduncAlma() {
	ifstream dosyaOku("okuyucular.txt");
	ofstream dosyaYazzz("Odunc.txt", ios::app);
	//kullan�c�dan veri girmesi istenir ve odunc.txt'ye girilen veriler yazd�r�l�r.
	do {
		cout << "kitab�n ISBN girin:\n";
		cin >> ISBN;
		cout << "okuyucunun tc kimlik numaras�n� girin:\n";
		cin >> tcNo;
		cout << "kitab�n �d�n� tarihini g�n.ay.y�l olacak �ekilde girin:\n";
		cin >> oduncTarih;
		cout << "kitab�n d�n�� tarihini g�n.ay.y�l olacak �ekilde girin:\n";
		cin >> donusTarih;
		dosyaYazzz << ISBN << " " << tcNo << " " << oduncTarih << " " << donusTarih  << endl;
		cout << "**i�lem ba�ar�yla tamamlanm��t�r**\n";
		cout << "yeni bir �d�n� i�lemi ger�ekle�tirmek istiyor musunuz(e/h)" << endl;
		cin >> kay�tDevam;

	} while (!(kay�tDevam == 'h'));
}
int geriDondurme() {
	long long arananISBN;
	cout << "d�n�� i�lemi yap�lacak kitab�n ISBN numaras�:";
	cin >> arananISBN;
	ifstream dosyaOkuuu("odunc.txt");
	ofstream dosyaYazzz("odunc.tmp", ios::app);
	//girilen veriler ile geri-d�n���m sa�lan�r ve veri silinir.
	while (true)
	{
		dosyaOkuuu >> ISBN >> tcNo >> oduncTarih >> donusTarih;
		if (dosyaOkuuu.eof()) {
			break;
		}
		if (arananISBN == ISBN)
		{
			cout << "kitab�n ISBN:" << ISBN << endl;
			cout << "kitab�n okuyucusunun TC numaras�:" << tcNo << endl;
			cout << "kitab�n �d�n� tarihi:" << oduncTarih << endl;
			cout << "kitab�n d�n�� tarihi:" << donusTarih << endl;
			cout << "**i�lem tamamlanm��t�r.**" << endl;

		}
		if (arananISBN != ISBN) {
			dosyaYazzz << ISBN << " " << tcNo << " " << oduncTarih << " " << donusTarih << endl;
		}


	}

	dosyaYazzz.close();
	dosyaOkuuu.close();
	int result;
	const char old[] = "odunc.tmp";
	const char neww[] = "odunc.txt";
	remove("odunc.txt");
	result = rename(old, neww);
	return result;

}
int geriDondurme2(long long arananTC) {
	ifstream dosyaOkuuu("odunc.txt");
	ofstream dosyaYazzz("odunc.tmp", ios::app);
	//okuyucu silindi�inde �d�n� i�lemi tamamlanmas� i�in olu�turulan d�ng�d�r.
	while (true)
	{
		dosyaOkuuu >> ISBN >> tcNo >> oduncTarih >> donusTarih;
		if (dosyaOkuuu.eof()) {
			break;
		}
		if (arananTC == tcNo)
		{
		}
		if (arananTC != tcNo) {
			dosyaYazzz << ISBN << " " << tcNo << " " << oduncTarih << " " << donusTarih << endl;
		}


	}

	dosyaYazzz.close();
	dosyaOkuuu.close();
	int result;
	const char old[] = "odunc.tmp";
	const char neww[] = "odunc.txt";
	remove("odunc.txt");
	result = rename(old, neww);
	return result;
}
void kitapEkleme() {
	ofstream dosyaYazk("kitaplar.txt", ios::app / ios::in);
	cout << "***l�tfen birden fazla kelime girmeniz halinde araya '_' i�aretini koyunuz.***\n";
	//kitaplar.txt'ye girilen veriler yazd�r�l�r.
	do {
		cout << "kitab�n ISBN girin:\n";
		cin >> ISBN;
		cout << "kitab�n ismini girin:\n";
		cin >> kitapIsmi;
		cout << "yazar�n ad�n� girin:\n";
		cin >> yazarAdi;
		cout << "yazar�n soyad�n� girin:\n";
		cin >> yazarSoyadi;
		cout << "kitab�n konusunu girin:\n";
		cin >> konu;
		cout << "kitab�n t�r�n� girin:\n";
		cin >> tur;
		cout << "kitab�n sayfa say�s�n� girin:\n";
		cin >> sayfaSayisi;
		dosyaYazk << ISBN << " " << kitapIsmi << " " << yazarAdi << " " << yazarSoyadi << " " << konu << " " << tur << " " << sayfaSayisi << endl;
		cout << "**kitap kayd� yap�lm��t�r.**\n";
		cout << "yeni bir kitap kayd� yapmak istiyor musunuz(e/h)" << endl;
		cin >> kay�tDevam;

	} while (!(kay�tDevam == 'h'));

}
int kitapSilme(){
	long long arananISBN;
	cout << "silme i�lemi yap�lacak kitab�n ISBN numaras�:";
	cin >> arananISBN;
	ifstream dosyaOkuk("kitaplar.txt");
	ofstream dosyaYazk("kitaplar.tmp", ios::app);
	//kitaplar.txt'de �sbn aran�r ve bulunursa kay�t silinir.
	while (true)
	{
			dosyaOkuk >> ISBN >> kitapIsmi >> yazarAdi >> yazarSoyadi >> konu >>
			tur >> sayfaSayisi;
		if (dosyaOkuk.eof()) {
			break;
		}
		if (arananISBN == ISBN)
		{
			cout << "\n--Silinecek Kitab�n Mevcut Bilgileri--\n";
			cout << "ISBN:" << ISBN << endl;
			cout << "Kitab�n �smi:" << kitapIsmi << endl;
			cout << "Yazar Ad�:" << yazarAdi << endl;
			cout << "Yazar Soyad�:" << yazarSoyadi << endl;
			cout << "Konu:" << konu<< endl;
			cout << "T�r:" << tur << endl;
			cout << "Sayfa Say�s�:" << sayfaSayisi << endl;
			cout << "**silme islemi tamamland�**" << endl;
			

		}
		if (arananISBN != ISBN) {
			dosyaYazk << ISBN << " " << kitapIsmi << " " << yazarAdi << " " << yazarSoyadi << " " << konu << " " << tur << " " << sayfaSayisi << endl;
			
		}


	}

	dosyaYazk.close();
	dosyaOkuk.close();
	int result;
	const char old[] = "kitaplar.tmp";
	const char neww[] = "kitaplar.txt";
	remove("kitaplar.txt");
	result = rename(old, neww);
	return result;
}
int kitapKaydiGuncelleme() {
	long long arananISBN;
	long long degerTutucu = 0;
	cout << "g�ncellemesi yap�lacak kitab�n ISBN numaras�:";
	cin >> arananISBN;
	ifstream dosyaOku("kitaplar.txt");
	ofstream dosyaYaz("kitaplar.tmp", ios::app);
	//kullan�c�n�n girdi�i ISBN ile kitaplar.txt'de veri aran�r ve mecvut veri ekrana yazd�r�l�r.
	//sonras�nda da girilen yeni veriler ile dosyada de�i�im sa�lan�r.
	while (true)
	{
		dosyaOku >> ISBN >> kitapIsmi >> yazarAdi >> yazarSoyadi >> konu >>
			tur >> sayfaSayisi;
		if (dosyaOku.eof()) {
			break;
		}
		if (arananISBN == ISBN)
		{
			cout << "\n--Kitab�n Mevcut Bilgileri--\n";
			cout << "ISBN:" << ISBN << endl;
			cout << "Kitab�n �smi:" << kitapIsmi << endl;
			cout << "Yazar Ad�:" << yazarAdi << endl;
			cout << "Yazar Soyad�:" << yazarSoyadi << endl;
			cout << "Konu:" << konu << endl;
			cout << "T�r:" << tur << endl;
			cout << "Sayfa Say�s�:" << sayfaSayisi << endl;
			cout << "\n--Kitab�n Yeni Bilgi Giri�i--" << endl;
			cout << "***l�tfen birden fazla kelime girmeniz halinde araya '_' i�aretini koyunuz.***\n";
			cout << "kitab�n ISBN girin:\n";
			cin >> ISBN;
			degerTutucu = ISBN;
			cout << "kitab�n ismini girin:\n";
			cin >> kitapIsmi;
			cout << "yazar�n ad�n� girin:\n";
			cin >> yazarAdi;
			cout << "yazar�n soyad�n� girin:\n";
			cin >> yazarSoyadi;
			cout << "kitab�n konusunu girin:\n";
			cin >> konu;
			cout << "kitab�n t�r�n� girin:\n";
			cin >> tur;
			cout << "kitab�n sayfa say�s�n� girin:\n";
			cin >> sayfaSayisi;
			dosyaYaz<< ISBN << " " << kitapIsmi << " " << yazarAdi << " " << yazarSoyadi << " " << konu << " " << tur << " " << sayfaSayisi << endl;
			ISBN = arananISBN;
		}
		if (arananISBN != ISBN)
		{
			dosyaYaz << ISBN << " " << kitapIsmi << " " << yazarAdi << " " << yazarSoyadi << " " << konu << " " << tur << " " << sayfaSayisi << endl;
		}


	}
	ISBN = degerTutucu;
	dosyaYaz.close();
	dosyaOku.close();
	int result;
	const char old[] = "kitaplar.tmp";
	const char neww[] = "kitaplar.txt";
	remove("kitaplar.txt");
	result = rename(old, neww);
	return result;
}
int okuyucuUzerindekiniGeriDondurme() {
	long long arananTc;
	cout << "silme i�lemi yap�lacak okuyucunun TC numaras�:";
	cin >> arananTc;
	ifstream dosyaOku("okuyucular.txt");
	ofstream dosyaYaz("okuyucular.tmp", ios::app);
	//silme i�lemi yap�l�r yukar�daki silme i�lemi ile buradaki aras�ndaki fark okuyucunun odun� i�leminin tamamlanmas�d�r.
	while (true)
	{
		dosyaOku >> tcNo >> ad >> soyad >> uyeNo >> telefon >>
			dogumTarihi >> gorev >> alinacakKitapSayisi;
		if (dosyaOku.eof()) {
			break;
		}
		if (arananTc == tcNo)
		{
			geriDondurme2(arananTc);
			cout << "\n--Silinecek Okuyucunun Mevcut Bilgileri--\n";
			cout << "TC:" << tcNo << endl;
			cout << "Ad:" << ad << endl;
			cout << "Soyad:" << soyad << endl;
			cout << "�ye no:" << uyeNo << endl;
			cout << "Telefon:" << telefon << endl;
			cout << "Do�um Tarihi:" << dogumTarihi << endl;
			cout << "G�rev:" << gorev << endl;
			cout << "Al�nacak Kitap Say�s�:" << alinacakKitapSayisi << endl;
			cout << "**silme islemi tamamland�**" << endl;

		}
		if (arananTc != tcNo) {
			dosyaYaz << tcNo << " " << ad << " " << soyad << " " << uyeNo << " " << telefon << " " << dogumTarihi << " " << gorev << " " << alinacakKitapSayisi << endl;
		}


	}

	dosyaYaz.close();
	dosyaOku.close();
	int result;
	const char old[] = "okuyucular.tmp";
	const char neww[] = "okuyucular.txt";
	remove("okuyucular.txt");
	result = rename(old, neww);
	return result;
}

int main() 
{
	setlocale(LC_ALL, "turkish");
	belirliKullanici();//iki tane kullan�c� belirlendi
	kullaniciGirisi();//kullan�c� giris yapar.
	ifstream dosyaOkuu("kullancilar.txt");
	//kullan�c�lar.txt'deki veriler okunmas� i�in olu�turulan basit d�ng�
	while (!dosyaOkuu.eof()) 
	{
		if ((kullaniciAdi == kullanici_adi) && (sifre == kullanici_sifre) || (kullaniciAdi == kullanici_adi1) && (sifre == kullanici_sifre1))//kullan�c� giris kontrolu
		{	//se�im s�ras�na g�re gerekli fonksiyonlar �a�r�l�r.
			girisSaat();
			anaMenu();
			if (secim == 1)
			{
				okuyucuKaydi();
				cikisSaat();
				break;
			}
			if (secim == 2)
			{
				okuyucuKaydiGuncelleme();
				cikisSaat();
				break;
			}
			if (secim == 3) 
			{
				okuyucuUzerindekiniGeriDondurme();
				cikisSaat();
				break;
			}
			if (secim == 4) {
				okuyucuUzerindekiKitap();
				cikisSaat();
				break;
			}
			if (secim == 5) {
				oduncAlma();
				cikisSaat();
				break;
			}//tc ile okuyucunun mevcut olup olmad���n� kontrol etmelisin.
			if (secim == 6) {
				geriDondurme();
				cikisSaat();
				break;
			}
			if (secim == 7) {
				kitapEkleme();
				cikisSaat();
				break;
			}
			if (secim == 8) {
				kitapSilme();
				cikisSaat();
				break;

			}
			if (secim == 9) {
				kitapKaydiGuncelleme();
				cikisSaat();
				break;
			}
		}
		else
		{
			cout << "hatali kullanici girisi";
			break;
		}
	}
	return 0;
}